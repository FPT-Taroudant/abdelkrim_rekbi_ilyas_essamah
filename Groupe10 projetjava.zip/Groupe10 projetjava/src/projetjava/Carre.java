package projetjava;

public class Carre {
	public float c;

	public float getC() {
		return c;
	}

	public void setC(float c) {
		this.c = c;
	}
	public void carre() {
		System.out.println("le carre du nombre"+this.c+" est ="+this.c*this.c);
	}


}

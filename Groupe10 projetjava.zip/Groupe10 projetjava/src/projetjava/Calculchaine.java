package projetjava;

public class Calculchaine {
	public float n;
	public float help;
	public char op;
	public float res;
	public char op2='x';
	
	
	public void setN(float n) {
		this.n = n;
	}

	public void setOp(char op) {
		this.op = op;
	}
	// le methodes 
	public void adition() {
        this.res=this.n+this.help;
		this.help=this.res;
	
	}
	public void soustraction() {
        this.res=this.help-this.n;
		this.help=this.res;
				
	}
	
	public void multiplication() {
		this.res=this.n*this.help;
		this.help=this.res;
	
	}
	public void division() {
		if(this.n==0) {
			System.out.println("la division sur 0 est impossible");
		}
		else {
			this.res=this.help/this.n;
		this.help=this.res;
		}
	
		//methode affichage 
	}
	public void affichage() {
		System.out.println("le resultat de calcule precedent est : "+this.res);
	}
	
	
	// methode calcule d'apres le choix du l'utulisateur
	
	public void calcule() {
		// pour le premiers element inserer dans la cahine
		if(this.op2=='x') {
			this.res=this.n;
			this.help=this.res; 
			affichage();
		}
		//pour le reste des elements de la chine 
		else if(this.op2=='+') {
			
	         adition();
			 affichage();
		}
		else if(this.op2=='-') {
		
			 soustraction();
			 affichage();
		}
		else if(this.op2=='*') {
		     multiplication();
			 affichage();
		}
		else if(this.op2=='/') {
		     division();
			 affichage();
		}
		
		this.op2=this.op; 
		
	}

}













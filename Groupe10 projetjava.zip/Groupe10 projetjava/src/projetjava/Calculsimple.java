package projetjava;

public class Calculsimple {
	

	public float a;
	public float b;
	public char op;
	
		public char getOp() {
		return op;
	}
	public void setOp(char op) {
		this.op = op;
	}
		public float getA() {
		return a;
	}
	public void setA(int a) {
		this.a = a;
	}
	public float getB() {
		return b;
	}
	public void setB(int b) {
		this.b = b;
	}
	// methodes
	public float adition() {
		return this.a+this.b;
		
	}
	public float soustraction() {
		return this.a-this.b;
		
	}
	public float multiplication() {
		
		return this.a*this.b;
		
	}
	public float division() {
		return this.a/this.b;
	
	}
	//methode de calcule
	public void resultat() {
	    if(this.op=='+') {
	        System.out.println("le resultat de a+b est = "+adition());
	}
	
	    else if(this.op=='-') {
	    	System.out.println("le resultat de a-b est = "+soustraction());	
	    }
	
	    else if(this.op=='*' ) {
	    	System.out.println("le resultat de a*b est = "+multiplication());	
	}
	    else if(this.op=='/' ) {
	    	if(this.b==0) {
	 		   System.out.println("division par 0 est impssible");
	 		}
	    	else {
	    		System.out.println("le resultat de a/b est = "+division());	
	    	}
	    	
	}
	    
	}
}



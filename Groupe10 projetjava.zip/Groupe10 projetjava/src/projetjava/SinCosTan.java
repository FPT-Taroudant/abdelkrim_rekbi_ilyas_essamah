package projetjava;

public class SinCosTan {
	float tr;

	public float getTr() {
		return tr;
	}

	public void setTr(float tr) {
		this.tr = tr;
	}
	
	public void trig() {
		
		System.out.println("* sin("+this.tr+") = "+Math.sin(tr));
		System.out.println("* cos("+this.tr+") = "+Math.cos(tr));
		System.out.println("* tan("+this.tr+") = "+Math.tan(tr));
	}

}

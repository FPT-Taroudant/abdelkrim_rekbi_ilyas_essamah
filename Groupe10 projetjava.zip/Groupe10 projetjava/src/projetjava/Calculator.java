/*
 
EZZAKI Hamza : calculs � la cha�ne
AIT M�BAREK Said : calcul  simple
WAHIA Asma : Calcul du carr� et racine carr�e d�un nombre
REZGUINI Abdelghani : Le cosinus, sinus et tangente.

*/
package projetjava;
import java.util.Scanner;
public class Calculator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	 Scanner kb = new Scanner(System.in);
	   
		int i;
		//MENU
		do {
			System.out.println("    ");
			System.out.println("    ");
			
		System.out.println("***********************-CALCULATRICE-************************");
		System.out.println("*************************************************************");
		System.out.println("****************************MENU*****************************");
		System.out.println("**  1-calcule simple                                       **");
		System.out.println("**  2-calcule a la chaine                                  **");
		System.out.println("**  3-calcule carre d'un nombre                            **");
		System.out.println("**  4-calcule la racine carre d'un nombre                  **");
		System.out.println("**  5-calcule le cosinus et sinus et tangente d'un nombre  **");
		System.out.println("**  taper 99 pour quiter                                   **");
		System.out.println("*************************************************************");
		System.out.println("*************************************************************");
		System.out.println("*************************************************************");
		System.out.println("    ");
		System.out.println("enter votre choix : ");
		i=kb.nextInt();
			
				switch(i)
		      {
			 case 1:
				 // calcul  simple
				 Calculsimple call0= new  Calculsimple();
				 int a;
				 int b;
				 char opp;
				 
				 System.out.println("entrer le premier nombre : ");
				 a=kb.nextInt();
				 call0.setA(a);
				 System.out.println("entrer le deuxieme nombre : ");
				 b=kb.nextInt();
				 call0.setB(b);
				 System.out.println("choisissez l'un des operations (+.-.*./) : ");
				 opp=kb.next().charAt(0);
				 call0.setOp(opp);
				 call0.resultat();
		 
			   break;
			   
			   
			 case 2:
				 //calculs � la cha�ne
		   Calculchaine call= new Calculchaine();
	     float nb;
		 char op;
		
		 System.out.println("entrer l'operation : ");
	
		 do {
			 
			 nb=kb.nextFloat();
			 call.setN(nb);
			
			 op=kb.next().charAt(0);
			 call.setOp(op);
			 
		     call.calcule();
			
		 }while(op!='=');
		 
			   break;
			   
			   
			 case 3:
				 //carre d'un nombre
				 Carre call1= new Carre();
				 float c;
				 System.out.println("entrer le nombre : ");
				 c=kb.nextFloat();
				 call1.setC(c);
				 call1.carre();
				
			  
			   break;
			
			 case 4:
				 // racine carre d'un nombre 
				 RacineCarre call2= new RacineCarre();
				 float rc;
				 System.out.println("entrer le nombre : ");
				 rc=kb.nextFloat();
				 call2.setRc(rc);
				 call2.racine();
				 
		           break; 
		           
			 case 5:
				 //Sin Cos Tan
				 SinCosTan call3= new SinCosTan();
				 float tr;
				 System.out.println("entrer le nombre : ");
				 tr=kb.nextFloat();
				 call3.setTr(tr);
				 call3.trig();
				 
		        
		           break;  
			 case 99:
				 System.out.println("�teint....");
		           
			 default:
				 System.out.println("CHOIX INVALIDE !!!!!");
		      }
			
			}while(i!=99);	
		System.out.println("by by ");
			
			 
			
	}

 
	

	
}
               
package projetjava;

public class RacineCarre {
	float rc;

	public float getRc() {
		return rc;
	}

	public void setRc(float rc) {
		this.rc = rc;
	}
	
	public void racine() {
		
		System.out.println("la racine carre du "+this.rc+" est = "+Math.sqrt(rc));
		
	}
     
}
